import time
import os
from flask import Flask ,render_template, request,send_file
  
app = Flask(__name__) #creating the Flask class object   

@app.route('/') #decorator drfines the   
def home(): 
    # return "hello, this is our first flask website";  
    return render_template('index.html')

@app.route('/static/<path:filename>', methods=['GET', 'POST'])
def download(filename):   
    print(app.root_path)
    full_path = os.path.join(app.root_path, filename)
    print(full_path) 
    return send_file(filename,as_attachement=True)

@app.route('/result')
def result():
    filename= 'result.txt'
    start = time.time()
    text = request.args.get('jsdata')
    # searchtext = '10.20.20.209'
    IpAddress = []
    with open('final.log','r') as read:
        for line in read:
            if text in line:
                IpAddress.append(line)
    with open('static/'+filename,'w') as w:
        w.writelines(IpAddress)

    listcount = len(IpAddress)
    actualtime = time.time() - start
    return render_template('result.html', ipaddresss=IpAddress,lenoflist = listcount,taketime=actualtime,resultfile=filename)
if __name__ =='__main__':  
    app.run(debug = True)  